// import { ReactDOM } from "../pdf/node_modules/react-dom";

// import { PDF_URL } from "../../App";
// import { degrees, PDFDocument, rgb, StandardFonts } from 'pdf-lib';
// import { saveAs } from 'file-saver';

// // https://pdf-lib.js.org/

// export async function printOnAnotherWindow(el) {
//   var printContents = ReactDOM.findDOMNode(el).innerHTML;
//   var windowObject = window.open('', "PrintWindow", "width=5, height=5, top=200, lefg=200, toolbars=no, scrollbars=no, status=no, resizable=no");

//   windowObject.document.writeln(printContents.innerHTML);
//   windowObject.document.close();
//   windowObject.focus();
//   windowObject.print();
//   windowObject.close();
// }
